# Docs Instructions

This folder will hold:

- Documentation pertaining to:
  - Command-line calls with option `-h, --help` or `/?`
  - Use current `sendEmails.txt` as a reference ONLY
- Markdown documentation for the tool
